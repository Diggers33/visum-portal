import React, { useState, useTransition } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Plus, Edit, Copy, Archive, Eye, BarChart } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '../ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../ui/select';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../ui/tabs';
import { toast } from 'sonner@2.0.3';
import EditAnnouncementModal from './EditAnnouncementModal';

const initialAnnouncements = [
  { 
    id: 1, 
    category: 'new-product', 
    categoryColor: 'bg-[#10b981] text-white', 
    title: 'New Product Launch: Visum Pro Series', 
    content: 'We are excited to announce the launch of our new Visum Pro series with enhanced sensitivity and faster processing speeds. These cutting-edge NIR analyzers will help your customers achieve unprecedented accuracy in quality control.', 
    date: 'Oct 28, 2025', 
    status: 'published', 
    views: 124, 
    clicks: 45,
    linkText: 'View Product Details',
    linkUrl: '/products/visum-pro',
    analytics: {
      clickThroughRate: 36,
      firstViewed: '1 hour after publishing',
      lastViewed: '2 hours ago',
      topViewer: { name: 'TechDist Global', count: 3 }
    }
  },
  { 
    id: 2, 
    category: 'marketing', 
    categoryColor: 'bg-[#8b5cf6] text-white', 
    title: 'Q4 Promotional Campaign Materials Available', 
    content: 'Access new marketing materials for our Q4 campaign including brochures, presentations, and social media assets. All materials are ready for immediate distribution to your customers.', 
    date: 'Oct 25, 2025', 
    status: 'published', 
    views: 98, 
    clicks: 34,
    linkText: 'Download Materials',
    linkUrl: '/marketing',
    analytics: {
      clickThroughRate: 35,
      firstViewed: '30 minutes after publishing',
      lastViewed: '5 hours ago',
      topViewer: { name: 'EuroPhotonics', count: 5 }
    }
  },
  { 
    id: 3, 
    category: 'documentation', 
    categoryColor: 'bg-[#3b82f6] text-white', 
    title: 'Updated Technical Documentation', 
    content: 'Installation guides and calibration procedures have been updated to reflect the latest best practices. Please review these changes to ensure optimal equipment performance.', 
    date: 'Oct 22, 2025', 
    status: 'published', 
    views: 76, 
    clicks: 28,
    analytics: {
      clickThroughRate: 37,
      firstViewed: '2 hours after publishing',
      lastViewed: '1 day ago',
      topViewer: { name: 'Nordic Tech Solutions', count: 2 }
    }
  },
  { 
    id: 4, 
    category: 'policy', 
    categoryColor: 'bg-[#f59e0b] text-white', 
    title: 'Updated Partner Pricing Policy', 
    content: 'Important: Our partner pricing structure has been updated to provide better margins for high-volume distributors. Please review the new pricing tiers and contact your account manager with any questions.', 
    date: '-', 
    status: 'draft', 
    views: 0, 
    clicks: 0 
  },
];

type Announcement = typeof initialAnnouncements[number];

type OptimisticAction =
  | { type: 'add'; announcement: Announcement }
  | { type: 'publish'; id: number }
  | { type: 'unpublish'; id: number }
  | { type: 'archive'; id: number }
  | { type: 'duplicate'; announcement: Announcement };

const categoryLabels: Record<string, string> = {
  'new-product': 'New Product',
  'marketing': 'Marketing',
  'documentation': 'Documentation',
  'training': 'Training',
  'policy': 'Policy',
  'general': 'General',
};

export default function AnnouncementsManagement() {
  const [activeTab, setActiveTab] = useState('published');
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingAnnouncement, setEditingAnnouncement] = useState<typeof initialAnnouncements[0] | null>(null);

  // Optimistic state management
  const [announcements, setAnnouncements] = useState(initialAnnouncements);
  const [isPending, startTransition] = useTransition();

  const handleCreateAnnouncement = (status: 'published' | 'draft') => {
    const newAnnouncement: Announcement = {
      id: Math.max(...announcements.map((a) => a.id)) + 1,
      category: 'General',
      categoryColor: 'bg-[#6b7280] text-white',
      title: 'New Announcement',
      content: 'Announcement content goes here...',
      date: status === 'published' ? 'Just now' : '-',
      status,
      views: 0,
      clicks: 0,
    };

    // Optimistic update - show immediately
    setAnnouncements((prev) => [...prev, newAnnouncement]);

    // Close dialog
    setIsCreateDialogOpen(false);

    // Switch to the appropriate tab
    if (status === 'published') {
      setActiveTab('published');
    } else {
      setActiveTab('draft');
    }

    startTransition(async () => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500));
      toast.success(`Announcement ${status === 'published' ? 'published' : 'saved as draft'}`);
    });
  };

  const handlePublish = (announcementId: number) => {
    // Optimistic update - publish instantly
    setAnnouncements((prev) =>
      prev.map((a) =>
        a.id === announcementId ? { ...a, status: 'published', date: 'Just now' } : a
      )
    );

    startTransition(async () => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500));
      toast.success('Announcement published');
    });
  };

  const handleArchive = (announcementId: number) => {
    const announcement = announcements.find((a) => a.id === announcementId);

    // Optimistic update - archive instantly
    setAnnouncements((prev) =>
      prev.map((a) => (a.id === announcementId ? { ...a, status: 'archived' } : a))
    );

    startTransition(async () => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500));
      toast.success(`${announcement?.title} archived`);
    });
  };

  const handleDuplicate = (announcementId: number) => {
    const announcement = announcements.find((a) => a.id === announcementId);
    if (!announcement) return;

    const duplicatedAnnouncement: Announcement = {
      ...announcement,
      id: Math.max(...announcements.map((a) => a.id)) + 1,
      title: `${announcement.title} (Copy)`,
      status: 'draft',
      date: '-',
      views: 0,
      clicks: 0,
      analytics: undefined, // Reset analytics for duplicate
    };

    // Optimistic update - show duplicate instantly
    setAnnouncements((prev) => [...prev, duplicatedAnnouncement]);

    // Switch to draft tab to show the duplicated announcement
    setActiveTab('draft');

    startTransition(async () => {
      // Simulate API call
      await new Promise((resolve) => setTimeout(resolve, 500));
      toast.success('Announcement duplicated and saved as draft');
    });
  };

  const handleUpdateAnnouncement = (updatedAnnouncement: Announcement) => {
    // Optimistic update
    setAnnouncements((prev) =>
      prev.map((a) => (a.id === updatedAnnouncement.id ? updatedAnnouncement : a))
    );
  };

  const filteredAnnouncements = announcements.filter(a => a.status === activeTab);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[28px] font-semibold text-slate-900 mb-2">Announcements</h1>
        <p className="text-[16px] text-[#6b7280]">Communicate updates to distributors</p>
      </div>

      <div className="flex items-center justify-between">
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-[#00a8b5] hover:bg-[#008a95] text-white">
              <Plus className="mr-2 h-4 w-4" />
              Create Announcement
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Announcement</DialogTitle>
              <DialogDescription>Create a new update for distributors</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="category">Category *</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new-product">New Product</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="documentation">Documentation</SelectItem>
                    <SelectItem value="training">Training</SelectItem>
                    <SelectItem value="policy">Policy</SelectItem>
                    <SelectItem value="general">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid gap-2">
                <Label htmlFor="title">Title *</Label>
                <Input id="title" placeholder="e.g., New Product Launch: Visum Pro Series" />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="content">Content *</Label>
                <textarea
                  id="content"
                  placeholder="Full announcement content..."
                  className="min-h-[150px] w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-[14px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="grid gap-2">
                  <Label htmlFor="linkText">Link Text (optional)</Label>
                  <Input id="linkText" placeholder="e.g., View Product Details" />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="linkUrl">Link URL (optional)</Label>
                  <Input id="linkUrl" placeholder="/products" />
                </div>
              </div>

              <div className="grid gap-2">
                <Label>Publish Date</Label>
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="immediately" name="publishDate" defaultChecked className="w-4 h-4" />
                    <Label htmlFor="immediately" className="font-normal cursor-pointer">Immediately</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="schedule" name="publishDate" className="w-4 h-4" />
                    <Label htmlFor="schedule" className="font-normal cursor-pointer">Schedule for</Label>
                    <Input type="date" className="w-40" />
                  </div>
                </div>
              </div>

              <div className="grid gap-2">
                <Label>Target Audience (optional)</Label>
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <Checkbox id="all-dist" defaultChecked />
                    <Label htmlFor="all-dist" className="font-normal cursor-pointer">All Distributors</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox id="specific-terr" />
                    <Label htmlFor="specific-terr" className="font-normal cursor-pointer">Specific territories</Label>
                  </div>
                </div>
              </div>

              <div className="grid gap-2">
                <Label>Status</Label>
                <div className="flex gap-4">
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="draft-ann" name="status" className="w-4 h-4" />
                    <Label htmlFor="draft-ann" className="font-normal cursor-pointer">Draft</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input type="radio" id="published-ann" name="status" defaultChecked className="w-4 h-4" />
                    <Label htmlFor="published-ann" className="font-normal cursor-pointer">Published</Label>
                  </div>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>Cancel</Button>
              <Button variant="outline" onClick={() => handleCreateAnnouncement('draft')}>Save as Draft</Button>
              <Button className="bg-[#00a8b5] hover:bg-[#008a95]" onClick={() => handleCreateAnnouncement('published')}>Publish Now</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="published">Published</TabsTrigger>
          <TabsTrigger value="draft">Drafts</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled</TabsTrigger>
          <TabsTrigger value="archived">Archived</TabsTrigger>
        </TabsList>

        <TabsContent value={activeTab} className="mt-6">
          <div className="space-y-4">
            {filteredAnnouncements.length === 0 ? (
              <Card className="border-slate-200">
                <CardContent className="p-12 text-center">
                  <p className="text-[15px] text-[#6b7280]">
                    No {activeTab} announcements
                  </p>
                </CardContent>
              </Card>
            ) : (
              filteredAnnouncements.map((announcement) => (
                <Card key={announcement.id} className="border-slate-200">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <Badge className={`${announcement.categoryColor} text-[12px]`}>
                          {categoryLabels[announcement.category] || announcement.category}
                        </Badge>
                        <Badge variant="outline" className="text-[11px]">
                          {announcement.status.charAt(0).toUpperCase() + announcement.status.slice(1)}
                        </Badge>
                      </div>
                      <span className="text-[13px] text-[#9ca3af]">{announcement.date}</span>
                    </div>

                    <h3 className="text-[18px] font-semibold text-slate-900 mb-2">{announcement.title}</h3>
                    <p className="text-[15px] text-[#6b7280] mb-4">{announcement.content}</p>

                    {announcement.status === 'published' && (
                      <div className="flex items-center gap-6 mb-4 text-[13px] text-[#6b7280]">
                        <div className="flex items-center gap-2">
                          <Eye className="h-4 w-4" />
                          <span>Views: {announcement.views}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <BarChart className="h-4 w-4" />
                          <span>Click-through: {announcement.clicks}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setEditingAnnouncement(announcement)}
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </Button>
                      {announcement.status === 'draft' && (
                        <Button 
                          size="sm" 
                          className="bg-[#00a8b5] hover:bg-[#008a95] text-white"
                          onClick={() => handlePublish(announcement.id)}
                        >
                          Publish Now
                        </Button>
                      )}
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleDuplicate(announcement.id)}
                        title="Create a copy of this announcement"
                      >
                        <Copy className="mr-2 h-4 w-4" />
                        Duplicate
                      </Button>
                      {announcement.status !== 'archived' && (
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleArchive(announcement.id)}
                        >
                          <Archive className="mr-2 h-4 w-4" />
                          Archive
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Edit Announcement Modal */}
      <EditAnnouncementModal
        announcement={editingAnnouncement}
        open={!!editingAnnouncement}
        onOpenChange={(open) => !open && setEditingAnnouncement(null)}
        onSave={handleUpdateAnnouncement}
        onArchive={handleArchive}
      />
    </div>
  );
}
