import React, { useState, useEffect, useTransition } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { 
  Plus, 
  Search, 
  Upload,
  Edit,
  Download,
  Trash2,
  ImageIcon,
  FileText,
  Video,
  Grid,
  List,
  MoreVertical
} from 'lucide-react';
import EditAssetModal from './EditAssetModal';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

const initialAssets = [
  { 
    id: 1, 
    name: 'Visum Palm Brochure', 
    type: 'Brochure', 
    product: 'Visum Palm', 
    language: 'English', 
    format: 'PDF', 
    size: '6.2 MB', 
    downloads: 142,
    uploaded: 'Oct 15, 2025',
    status: 'published',
    description: 'Product overview and specifications brochure',
    internalNotes: 'Updated with new product imagery',
    lastDownloaded: '1 hour ago',
    lastDownloadedBy: 'TechDist Global',
    created: 'Jan 10, 2024',
  },
  { 
    id: 2, 
    name: 'Product Photos - HyperSpec', 
    type: 'Product Photos', 
    product: 'HyperSpec HS-2000', 
    language: 'All Languages', 
    format: 'ZIP', 
    size: '45 MB', 
    downloads: 89,
    uploaded: 'Oct 8, 2025',
    status: 'published',
    description: 'High-resolution product photography package',
    internalNotes: '',
    lastDownloaded: '5 hours ago',
    lastDownloadedBy: 'EuroPhotonics',
    created: 'Mar 15, 2024',
  },
  { 
    id: 3, 
    name: 'Raman Application Video', 
    type: 'Video', 
    product: 'Raman RXN5', 
    language: 'English', 
    format: 'MP4', 
    size: '125 MB', 
    downloads: 56,
    uploaded: 'Sep 28, 2025',
    status: 'published',
    description: 'Pharmaceutical application demonstration',
    internalNotes: 'Consider creating subtitled versions',
    lastDownloaded: '2 days ago',
    lastDownloadedBy: 'Asia Pacific Instruments',
    created: 'Sep 1, 2025',
  },
  { 
    id: 4, 
    name: 'IRIS Company Logo Pack', 
    type: 'Logo', 
    product: 'General/Company', 
    language: 'All Languages', 
    format: 'ZIP', 
    size: '2.1 MB', 
    downloads: 234,
    uploaded: 'Jul 12, 2025',
    status: 'published',
    description: 'Complete brand identity assets',
    internalNotes: 'Includes vector and raster formats',
    lastDownloaded: '30 minutes ago',
    lastDownloadedBy: 'Nordic Tech Solutions',
    created: 'Jul 12, 2025',
  },
  { 
    id: 5, 
    name: 'Pharma Case Study', 
    type: 'Case Study', 
    product: 'Visum Palm', 
    language: 'English', 
    format: 'PDF', 
    size: '3.8 MB', 
    downloads: 67,
    uploaded: 'Oct 20, 2025',
    status: 'published',
    description: 'Quality control success story',
    internalNotes: 'Customer approved for public use',
    lastDownloaded: '1 day ago',
    lastDownloadedBy: 'TechDist Global',
    created: 'Oct 15, 2025',
  },
];

export default function MarketingManagement() {
  const [isPending, startTransition] = useTransition();
  const [assets, setAssets] = useState(initialAssets);
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<typeof initialAssets[0] | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Set document title
  useEffect(() => {
    document.title = 'Marketing Assets - IRIS Admin';
    return () => {
      document.title = 'IRIS Admin Portal';
    };
  }, []);

  const filteredAssets = assets.filter((asset) =>
    asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    asset.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleEditAsset = (asset: typeof initialAssets[0]) => {
    setEditingAsset(asset);
    setIsEditModalOpen(true);
  };

  const handleSaveAsset = (updatedAsset: typeof initialAssets[0]) => {
    // Use startTransition for optimistic update
    startTransition(() => {
      setAssets(prev => 
        prev.map(asset => asset.id === updatedAsset.id ? updatedAsset : asset)
      );
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[28px] font-semibold text-slate-900 mb-2">Marketing Assets</h1>
        <p className="text-[16px] text-[#6b7280]">Manage marketing materials and media</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-3 flex-1 w-full">
          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#00a8b5] hover:bg-[#008a95] text-white">
                <Plus className="mr-2 h-4 w-4" />
                Upload Assets
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload Marketing Assets</DialogTitle>
                <DialogDescription>Upload marketing materials (supports multiple files)</DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label>Upload Files *</Label>
                  <div className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center hover:border-[#00a8b5] transition-colors cursor-pointer">
                    <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-[13px] text-[#6b7280]">Click to upload or drag and drop multiple files</p>
                    <p className="text-[12px] text-[#9ca3af]">PDF, JPG, PNG, MP4, ZIP files • Max 200MB per file</p>
                    <Button variant="outline" size="sm" className="mt-3">
                      Browse Files
                    </Button>
                  </div>
                  <p className="text-[12px] text-[#6b7280] italic">💡 Tip: Asset type will be auto-detected based on file extension</p>
                </div>

                {/* File Preview Area (appears after files selected) */}
                <div className="grid gap-2">
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-[13px] text-[#6b7280]">
                    <p className="font-medium text-slate-900 mb-2">Selected Files (0)</p>
                    <p className="text-[12px] text-[#9ca3af]">Your files will appear here after selection</p>
                  </div>
                </div>

                <div className="border-t border-slate-200 pt-4 space-y-4">
                  <p className="text-[13px] font-semibold text-slate-900">Apply to All Files:</p>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div className="grid gap-2">
                      <Label htmlFor="assetType">Asset Type</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Auto-detect" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto">Auto-detect from file</SelectItem>
                          <SelectItem value="brochure">Brochure</SelectItem>
                          <SelectItem value="photos">Product Photos</SelectItem>
                          <SelectItem value="video">Video</SelectItem>
                          <SelectItem value="logo">Logo</SelectItem>
                          <SelectItem value="case-study">Case Study</SelectItem>
                          <SelectItem value="white-paper">White Paper</SelectItem>
                          <SelectItem value="presentation">Presentation</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="grid gap-2">
                      <Label htmlFor="assetProduct">Product</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select product" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="visum-palm">Visum Palm</SelectItem>
                          <SelectItem value="raman">Raman RXN5</SelectItem>
                          <SelectItem value="hyperspec">HyperSpec HS-2000</SelectItem>
                          <SelectItem value="visum-pro">Visum Pro</SelectItem>
                          <SelectItem value="general">General/Company</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="assetLang">Language</Label>
                    <Select defaultValue="en">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                        <SelectItem value="it">Italian</SelectItem>
                        <SelectItem value="all">All Languages</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="status">Status</Label>
                    <div className="flex gap-4">
                      <div className="flex items-center space-x-2">
                        <input type="radio" id="upload-published" name="upload-status" value="published" defaultChecked className="w-4 h-4" />
                        <Label htmlFor="upload-published" className="font-normal cursor-pointer text-[13px]">Published</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="radio" id="upload-draft" name="upload-status" value="draft" className="w-4 h-4" />
                        <Label htmlFor="upload-draft" className="font-normal cursor-pointer text-[13px]">Draft</Label>
                      </div>
                    </div>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="description">Description (Optional)</Label>
                    <textarea
                      id="description"
                      placeholder="Add description for all files..."
                      className="min-h-[60px] w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-[14px]"
                    />
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>Cancel</Button>
                <Button className="bg-[#00a8b5] hover:bg-[#008a95]">Upload All Assets</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <div className="flex-1 relative min-w-0">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              type="search"
              placeholder="Search assets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white border-slate-200"
            />
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            variant={viewMode === 'grid' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('grid')}
          >
            <Grid className="h-4 w-4" />
          </Button>
          <Button
            variant={viewMode === 'list' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setViewMode('list')}
          >
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex gap-6">
        <Card className="w-64 h-fit border-slate-200 hidden lg:block">
          <CardContent className="p-4 space-y-4">
            <div>
              <h3 className="text-[14px] font-semibold text-slate-900 mb-3">Asset Type</h3>
              <div className="space-y-2">
                {['Brochure', 'Product Photos', 'Video', 'Logo', 'Case Study'].map((type) => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox id={type} />
                    <Label htmlFor={type} className="text-[13px] font-normal cursor-pointer">{type}</Label>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredAssets.map((asset) => {
              const Icon = asset.format === 'PDF' ? FileText : asset.format === 'MP4' ? Video : ImageIcon;
              return (
                <Card key={asset.id} className="border-slate-200 hover:shadow-lg transition-shadow">
                  <CardContent className="p-4">
                    <div className="aspect-[4/3] bg-slate-100 rounded-lg mb-3 flex items-center justify-center">
                      <Icon className="h-12 w-12 text-slate-400" />
                    </div>
                    <Badge className="mb-2 text-[11px]">{asset.type}</Badge>
                    <h3 className="font-semibold text-slate-900 mb-1 text-[14px]">{asset.name}</h3>
                    <p className="text-[12px] text-[#6b7280] mb-2">{asset.format} • {asset.size}</p>
                    <p className="text-[12px] text-[#9ca3af] mb-3">{asset.downloads} downloads</p>
                    
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="flex-1 text-[12px]" onClick={() => handleEditAsset(asset)}>
                        <Edit className="mr-1 h-3 w-3" />
                        Edit
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button size="sm" variant="outline">
                            <MoreVertical className="h-3 w-3" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem><Download className="mr-2 h-4 w-4" />Download</DropdownMenuItem>
                          <DropdownMenuItem><Upload className="mr-2 h-4 w-4" />Replace</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600"><Trash2 className="mr-2 h-4 w-4" />Delete</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>

      {/* Edit Asset Modal */}
      <EditAssetModal
        asset={editingAsset}
        open={isEditModalOpen}
        onOpenChange={setIsEditModalOpen}
        onSave={handleSaveAsset}
      />
    </div>
  );
}
