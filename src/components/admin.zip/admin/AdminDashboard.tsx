import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '../ui/card';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { 
  Users, 
  FolderOpen, 
  Download, 
  Megaphone,
  Plus,
  Upload,
  Eye,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';

const stats = [
  {
    title: 'Active Distributors',
    value: '24',
    subtitle: '4 new this month',
    icon: Users,
    color: 'text-[#00a8b5]',
    bgColor: 'bg-[#00a8b5]/10',
  },
  {
    title: 'Total Resources',
    value: '156',
    subtitle: '42 docs | 68 marketing | 46 training',
    icon: FolderOpen,
    color: 'text-[#00a8b5]',
    bgColor: 'bg-[#00a8b5]/10',
  },
  {
    title: 'Recent Activity',
    value: '89',
    subtitle: 'downloads in last 30 days',
    icon: Download,
    color: 'text-[#00a8b5]',
    bgColor: 'bg-[#00a8b5]/10',
  },
  {
    title: 'Announcements',
    value: '5',
    subtitle: '2 drafts pending',
    icon: Megaphone,
    color: 'text-[#00a8b5]',
    bgColor: 'bg-[#00a8b5]/10',
  },
];

const quickActions = [
  {
    label: 'Add Distributor',
    icon: Plus,
    href: '/admin/distributors',
    color: 'bg-[#00a8b5] hover:bg-[#008a95]',
  },
  {
    label: 'Upload Content',
    icon: Upload,
    href: '/admin/documentation',
    color: 'bg-[#00a8b5] hover:bg-[#008a95]',
  },
  {
    label: 'Post Announcement',
    icon: Megaphone,
    href: '/admin/announcements',
    color: 'bg-[#00a8b5] hover:bg-[#008a95]',
  },
];

const recentActivity = [
  {
    id: 1,
    action: 'TechDist Global downloaded Visum Palm brochure',
    time: '2 hours ago',
    type: 'download',
  },
  {
    id: 2,
    action: 'German Partner GmbH viewed Products page',
    time: '4 hours ago',
    type: 'view',
  },
  {
    id: 3,
    action: 'New account created: French Distributor SARL',
    time: '6 hours ago',
    type: 'account',
  },
  {
    id: 4,
    action: 'Documentation updated: Raman RXN5 Manual v2.1',
    time: '1 day ago',
    type: 'update',
  },
  {
    id: 5,
    action: 'Spanish Distributor downloaded spec sheet',
    time: '1 day ago',
    type: 'download',
  },
  {
    id: 6,
    action: 'Announcement published: Q4 Campaign',
    time: '2 days ago',
    type: 'announcement',
  },
  {
    id: 7,
    action: 'TechDist Deutschland viewed Training Center',
    time: '2 days ago',
    type: 'view',
  },
  {
    id: 8,
    action: 'Italian Partner logged in',
    time: '3 days ago',
    type: 'login',
  },
];

const pendingTasks = [
  {
    id: 1,
    task: '3 draft announcements need review',
    priority: 'medium',
    link: '/admin/announcements',
  },
  {
    id: 2,
    task: '2 new distributor applications pending approval',
    priority: 'high',
    link: '/admin/distributors',
  },
];

export default function AdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-[28px] font-semibold text-slate-900 mb-2">Admin Dashboard</h1>
        <p className="text-[16px] text-[#6b7280]">Manage your distributor portal</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          return (
            <Card key={stat.title} className="border-slate-200">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-2">
                    <p className="text-[13px] text-[#6b7280]">{stat.title}</p>
                    <p className="text-[32px] font-semibold text-slate-900">{stat.value}</p>
                    <p className="text-[12px] text-[#9ca3af]">{stat.subtitle}</p>
                  </div>
                  <div className={`${stat.bgColor} ${stat.color} p-3 rounded-lg`}>
                    <Icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Actions */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-[18px]">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Link key={action.label} to={action.href}>
                  <Button
                    className={`w-full ${action.color} text-white justify-start gap-3`}
                  >
                    <Icon className="h-5 w-5" />
                    {action.label}
                  </Button>
                </Link>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Pending Tasks */}
      {pendingTasks.length > 0 && (
        <Card className="border-orange-200 bg-orange-50/50">
          <CardHeader>
            <CardTitle className="text-[18px] text-orange-900">Pending Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pendingTasks.map((task) => (
                <div
                  key={task.id}
                  className="flex items-center justify-between p-4 bg-white rounded-lg border border-orange-200"
                >
                  <div className="flex items-center gap-3">
                    {task.priority === 'high' && (
                      <Badge className="bg-red-500 text-white">High Priority</Badge>
                    )}
                    {task.priority === 'medium' && (
                      <Badge className="bg-orange-500 text-white">Medium</Badge>
                    )}
                    <span className="text-[14px] text-slate-900">{task.task}</span>
                  </div>
                  <Link to={task.link}>
                    <Button variant="ghost" size="sm" className="text-[#00a8b5] hover:text-[#008a95]">
                      Review
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Activity */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-[18px]">Recent Platform Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity) => (
              <div key={activity.id} className="flex items-start gap-4 pb-4 border-b border-slate-100 last:border-0">
                <div className="w-2 h-2 mt-2 bg-[#00a8b5] rounded-full flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-[14px] text-slate-900">{activity.action}</p>
                  <p className="text-[12px] text-[#9ca3af] mt-1">{activity.time}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-slate-200">
            <Link to="/admin/analytics" className="text-[14px] text-[#00a8b5] hover:text-[#008a95] flex items-center gap-2">
              View All Activity
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
