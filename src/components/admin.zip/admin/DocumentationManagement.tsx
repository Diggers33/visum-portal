import React, { useState, useEffect, useTransition } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { 
  Plus, 
  Search, 
  Upload,
  Edit,
  Download,
  Trash2,
  FileText,
  MoreVertical
} from 'lucide-react';
import EditDocumentModal from './EditDocumentModal';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

const initialDocuments = [
  {
    id: 1,
    title: 'Visum Palm User Manual',
    product: 'Visum Palm',
    category: 'User Manual',
    version: 'v2.3',
    uploaded: 'Oct 15, 2025',
    status: 'published',
    downloads: 45,
    fileSize: '6.2 MB',
    format: 'PDF',
    language: 'English',
    internalNotes: 'Updated with new safety guidelines and troubleshooting section.',
    lastDownloaded: '2 hours ago',
    lastDownloadedBy: 'TechDist Global',
    created: 'Jan 15, 2020',
  },
  {
    id: 2,
    title: 'Raman RXN5 Installation Guide',
    product: 'Raman RXN5',
    category: 'Installation Guide',
    version: 'v1.5',
    uploaded: 'Oct 10, 2025',
    status: 'published',
    downloads: 28,
    fileSize: '3.8 MB',
    format: 'PDF',
    language: 'English',
    internalNotes: '',
    lastDownloaded: '1 day ago',
    lastDownloadedBy: 'EuroPhotonics',
    created: 'Mar 10, 2021',
  },
  {
    id: 3,
    title: 'HyperSpec HS-2000 Technical Datasheet',
    product: 'HyperSpec HS-2000',
    category: 'Technical Datasheet',
    version: 'v1.0',
    uploaded: 'Oct 5, 2025',
    status: 'published',
    downloads: 67,
    fileSize: '1.2 MB',
    format: 'PDF',
    language: 'English',
    internalNotes: 'Final version approved by engineering team.',
    lastDownloaded: '3 hours ago',
    lastDownloadedBy: 'Asia Pacific Instruments',
    created: 'Jul 22, 2022',
  },
  {
    id: 4,
    title: 'Visum Pro Quick Start Guide',
    product: 'Visum Pro',
    category: 'Quick Start Guide',
    version: 'v1.0',
    uploaded: 'Oct 1, 2025',
    status: 'draft',
    downloads: 0,
    fileSize: '2.1 MB',
    format: 'PDF',
    language: 'English',
    internalNotes: 'Pending final review from product management.',
    lastDownloaded: undefined,
    lastDownloadedBy: undefined,
    created: 'Sep 28, 2025',
  },
];

export default function DocumentationManagement() {
  const [isPending, startTransition] = useTransition();
  const [documents, setDocuments] = useState(initialDocuments);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUploadDialogOpen, setIsUploadDialogOpen] = useState(false);
  const [editingDocument, setEditingDocument] = useState<typeof initialDocuments[0] | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Set document title
  useEffect(() => {
    document.title = 'Documentation Management - IRIS Admin';
    return () => {
      document.title = 'IRIS Admin Portal';
    };
  }, []);

  const filteredDocs = documents.filter((doc) =>
    doc.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doc.product.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleEditDocument = (doc: typeof initialDocuments[0]) => {
    setEditingDocument(doc);
    setIsEditModalOpen(true);
  };

  const handleSaveDocument = (updatedDoc: typeof initialDocuments[0]) => {
    // Use startTransition for optimistic update
    startTransition(() => {
      setDocuments(prev => 
        prev.map(doc => doc.id === updatedDoc.id ? updatedDoc : doc)
      );
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-[28px] font-semibold text-slate-900 mb-2">Documentation</h1>
        <p className="text-[16px] text-[#6b7280]">Manage technical documents and manuals</p>
      </div>

      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="flex flex-col sm:flex-row gap-3 flex-1 w-full">
          <Dialog open={isUploadDialogOpen} onOpenChange={setIsUploadDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-[#00a8b5] hover:bg-[#008a95] text-white">
                <Plus className="mr-2 h-4 w-4" />
                Upload Document
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Upload Document</DialogTitle>
                <DialogDescription>Add a new technical document to the portal</DialogDescription>
              </DialogHeader>
              
              <div className="grid gap-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="file">Upload File *</Label>
                  <div className="border-2 border-dashed border-slate-200 rounded-lg p-8 text-center">
                    <Upload className="h-8 w-8 text-slate-400 mx-auto mb-2" />
                    <p className="text-[13px] text-[#6b7280]">Click to upload or drag and drop</p>
                    <p className="text-[12px] text-[#9ca3af]">PDF, DOC, DOCX up to 50MB</p>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="docTitle">Document Title *</Label>
                  <Input id="docTitle" placeholder="e.g., Visum Palm User Manual" />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-2">
                    <Label htmlFor="product">Product *</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select product" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="visum-palm">Visum Palm</SelectItem>
                        <SelectItem value="raman-rxn5">Raman RXN5</SelectItem>
                        <SelectItem value="hyperspec">HyperSpec HS-2000</SelectItem>
                        <SelectItem value="all">All Products</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="category">Category *</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="manual">User Manual</SelectItem>
                        <SelectItem value="installation">Installation Guide</SelectItem>
                        <SelectItem value="datasheet">Technical Datasheet</SelectItem>
                        <SelectItem value="quickstart">Quick Start Guide</SelectItem>
                        <SelectItem value="specs">Specifications</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="grid gap-2">
                    <Label htmlFor="version">Version Number</Label>
                    <Input id="version" placeholder="e.g., v2.3" />
                  </div>

                  <div className="grid gap-2">
                    <Label htmlFor="language">Language</Label>
                    <Select defaultValue="en">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="de">German</SelectItem>
                        <SelectItem value="fr">French</SelectItem>
                        <SelectItem value="es">Spanish</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <textarea
                    id="description"
                    placeholder="Brief description of the document..."
                    className="min-h-[80px] w-full rounded-md border border-slate-200 bg-white px-3 py-2 text-[14px]"
                  />
                </div>

                <div className="grid gap-2">
                  <Label>Status</Label>
                  <div className="flex gap-4">
                    <div className="flex items-center space-x-2">
                      <input type="radio" id="draft-status" name="status" className="w-4 h-4" />
                      <Label htmlFor="draft-status" className="font-normal cursor-pointer">Draft</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <input type="radio" id="published-status" name="status" defaultChecked className="w-4 h-4" />
                      <Label htmlFor="published-status" className="font-normal cursor-pointer">Published</Label>
                    </div>
                  </div>
                </div>
              </div>

              <DialogFooter>
                <Button variant="outline" onClick={() => setIsUploadDialogOpen(false)}>
                  Cancel
                </Button>
                <Button className="bg-[#00a8b5] hover:bg-[#008a95]">Upload Document</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          <div className="flex-1 relative min-w-0">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <Input
              type="search"
              placeholder="Search documents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-white border-slate-200"
            />
          </div>
        </div>

        <Button variant="outline" className="border-slate-200">
          <Upload className="mr-2 h-4 w-4" />
          Bulk Upload
        </Button>
      </div>

      {/* Filters + Table */}
      <div className="flex gap-6">
        {/* Filters */}
        <Card className="w-64 h-fit border-slate-200 hidden lg:block">
          <CardContent className="p-4 space-y-4">
            <div>
              <h3 className="text-[14px] font-semibold text-slate-900 mb-3">Category</h3>
              <div className="space-y-2">
                {['User Manual', 'Installation Guide', 'Technical Datasheet', 'Quick Start Guide'].map((cat) => (
                  <div key={cat} className="flex items-center space-x-2">
                    <Checkbox id={cat.toLowerCase().replace(' ', '-')} />
                    <Label htmlFor={cat.toLowerCase().replace(' ', '-')} className="text-[13px] font-normal cursor-pointer">
                      {cat}
                    </Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-slate-200 pt-4">
              <h3 className="text-[14px] font-semibold text-slate-900 mb-3">Status</h3>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox id="pub-docs" defaultChecked />
                  <Label htmlFor="pub-docs" className="text-[13px] font-normal cursor-pointer">Published</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="draft-docs" />
                  <Label htmlFor="draft-docs" className="text-[13px] font-normal cursor-pointer">Draft</Label>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Table */}
        <Card className="flex-1 border-slate-200">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Document Title</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Version</TableHead>
                  <TableHead>Uploaded</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Downloads</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredDocs.map((doc) => (
                  <TableRow key={doc.id}>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <FileText className="h-4 w-4 text-slate-400" />
                        <div>
                          <p className="font-medium text-slate-900">{doc.title}</p>
                          <p className="text-[12px] text-[#9ca3af]">{doc.format} • {doc.fileSize}</p>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-[13px]">{doc.product}</TableCell>
                    <TableCell className="text-[13px]">{doc.category}</TableCell>
                    <TableCell className="text-[13px]">{doc.version}</TableCell>
                    <TableCell className="text-[13px] text-[#6b7280]">{doc.uploaded}</TableCell>
                    <TableCell>
                      <Badge className={doc.status === 'published' ? 'bg-green-100 text-green-700 hover:bg-green-100' : 'bg-slate-100 text-slate-700 hover:bg-slate-100'}>
                        {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[13px]">{doc.downloads}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="sm">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEditDocument(doc)}>
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Upload className="mr-2 h-4 w-4" />
                            Replace
                          </DropdownMenuItem>
                          <DropdownMenuItem>
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem className="text-red-600">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {/* Edit Document Modal */}
      <EditDocumentModal
        document={editingDocument}
        open={isEditModalOpen}
        onOpenChange={setIsEditModalOpen}
        onSave={handleSaveDocument}
      />
    </div>
  );
}
