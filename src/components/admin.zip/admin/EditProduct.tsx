import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Textarea } from '../ui/textarea';
import { Label } from '../ui/label';
import { Checkbox } from '../ui/checkbox';
import { RadioGroup, RadioGroupItem } from '../ui/radio-group';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../ui/select';
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from '../ui/breadcrumb';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '../ui/alert-dialog';
import { ChevronRight, X, Plus, Eye, Download, Upload, Loader2, Trash2, Package } from 'lucide-react';
import { toast } from 'sonner';
import {
  fetchProductById,
  updateProduct,
  deleteProduct,
  type Product
} from '../../lib/api/products';
import { ImageWithFallback } from '../figma/ImageWithFallback';

interface Specification {
  id: string;
  label: string;
  value: string;
}

export default function EditProduct() {
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [product, setProduct] = useState<Product | null>(null);

  // Form state
  const [productData, setProductData] = useState({
    name: '',
    product_line: 'NIR Spectroscopy',
    description: '',
    price: '',
    currency: 'EUR',
    status: 'published' as 'draft' | 'published' | 'archived',
  });

  const [productImage, setProductImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [specifications, setSpecifications] = useState<Specification[]>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [newFeature, setNewFeature] = useState('');

  // Load product data on mount
  useEffect(() => {
    if (id) {
      loadProduct();
    }
  }, [id]);

  const loadProduct = async () => {
    if (!id) return;

    setIsLoading(true);
    const { data, error } = await fetchProductById(id);

    if (error) {
      toast.error('Failed to load product');
      console.error(error);
      navigate('/admin/products');
      return;
    }

    if (data) {
      setProduct(data);
      setProductData({
        name: data.name,
        product_line: data.product_line,
        description: data.description || '',
        price: data.price.toString(),
        currency: data.currency,
        status: data.status,
      });

      if (data.image_url) {
        setImagePreview(data.image_url);
      }

      // Load specifications
      if (data.specifications) {
        const specsArray = Object.entries(data.specifications).map(([key, value], index) => ({
          id: index.toString(),
          label: key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()),
          value: String(value)
        }));
        setSpecifications(specsArray);
      }

      // Load features
      if (data.features) {
        setFeatures(data.features);
      }
    }

    setIsLoading(false);
  };

  const handleFieldChange = (field: string, value: string) => {
    setProductData({ ...productData, [field]: value });
    setHasUnsavedChanges(true);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setProductImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setHasUnsavedChanges(true);
    }
  };

  const addSpecification = () => {
    const newSpec: Specification = {
      id: Date.now().toString(),
      label: '',
      value: '',
    };
    setSpecifications([...specifications, newSpec]);
    setHasUnsavedChanges(true);
  };

  const removeSpecification = (id: string) => {
    setSpecifications(specifications.filter(spec => spec.id !== id));
    setHasUnsavedChanges(true);
  };

  const updateSpecification = (id: string, field: 'label' | 'value', value: string) => {
    setSpecifications(
      specifications.map(spec =>
        spec.id === id ? { ...spec, [field]: value } : spec
      )
    );
    setHasUnsavedChanges(true);
  };

  const addFeature = () => {
    if (newFeature.trim()) {
      setFeatures([...features, newFeature.trim()]);
      setNewFeature('');
      setHasUnsavedChanges(true);
    }
  };

  const removeFeature = (index: number) => {
    setFeatures(features.filter((_, i) => i !== index));
    setHasUnsavedChanges(true);
  };

const handleSave = async () => {
  if (!id) return;

  // Validate required fields
  if (!productData.name || !productData.price) {
    toast.error('Please fill in all required fields');
    return;
  }

  // Prevent double-saves
  if (isSaving) {
    console.log('Already saving, ignoring duplicate request');
    return;
  }

  console.log('🔍 Starting save...', { id, productData });
  setIsSaving(true);

  // Fail-safe: Force reset after 10 seconds
  const saveTimeout = setTimeout(() => {
    console.warn('⚠️ Save timeout - forcing button re-enable');
    setIsSaving(false);
    toast.error('Save operation timed out. Please try again.');
  }, 10000);

  try {
    // Convert specifications array to object
    const specificationsObj = specifications.reduce((acc, spec) => {
      if (spec.label && spec.value) {
        const key = spec.label.toLowerCase().replace(/\s+/g, '_');
        acc[key] = spec.value;
      }
      return acc;
    }, {} as Record<string, any>);

    console.log('📤 Calling updateProduct...');
    
    const { data, error } = await updateProduct(id, {
      name: productData.name,
      product_line: productData.product_line,
      description: productData.description,
      price: parseFloat(productData.price),
      currency: productData.currency,
      status: productData.status,
      image: productImage || undefined,
      specifications: Object.keys(specificationsObj).length > 0 ? specificationsObj : undefined,
      features: features.length > 0 ? features : undefined,
    });

    console.log('📥 Update result:', { data, error });

    if (error) {
      throw error;
    }

  clearTimeout(saveTimeout);
toast.success('Product updated successfully');
setHasUnsavedChanges(false);
    
// Reload product data to get fresh data from database
console.log('🔄 Reloading product data...');
await loadProduct();
console.log('✅ Product data reloaded');

// Navigate back to products page after successful save
console.log('✅ Save complete, navigating back...');
setTimeout(() => {
  navigate('/admin/products');
}, 1500);
    
  } catch (error) {
    clearTimeout(saveTimeout);
    console.error('❌ Save error:', error);
    toast.error('Failed to update product');
  } finally {
    // ALWAYS reset saving state
    console.log('🔄 Resetting isSaving to false');
    setIsSaving(false);
  }
};

  const handleDelete = async () => {
    if (!id) return;

    setIsDeleting(true);
    const { success, error } = await deleteProduct(id);

    if (error) {
      toast.error('Failed to delete product');
      console.error(error);
      setIsDeleting(false);
    } else {
      toast.success('Product deleted successfully');
      navigate('/admin/products');
    }
  };

  const handleCancel = () => {
    if (hasUnsavedChanges) {
      setShowCancelDialog(true);
    } else {
      navigate('/admin/products');
    }
  };

  const confirmCancel = () => {
    setShowCancelDialog(false);
    navigate('/admin/products');
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-[#00a8b5]" />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <Package className="h-16 w-16 text-slate-300 mx-auto mb-4" />
        <p className="text-[#6b7280]">Product not found</p>
        <Button onClick={() => navigate('/admin/products')} className="mt-4">
          Back to Products
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      {/* Breadcrumb */}
      <Breadcrumb>
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild>
              <Link to="/admin/products">Products</Link>
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator>
            <ChevronRight className="h-4 w-4" />
          </BreadcrumbSeparator>
          <BreadcrumbItem>
            <BreadcrumbPage>Edit Product</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-[28px] font-semibold text-slate-900 mb-2">Edit Product</h1>
          <p className="text-[16px] text-[#6b7280]">{productData.name}</p>
        </div>
        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={() => setShowDeleteDialog(true)}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Delete
          </Button>
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave} 
            className="bg-[#00a8b5] hover:bg-[#008a95]"
            disabled={isSaving}
          >
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Information */}
          <Card className="border-slate-200">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-[18px] font-semibold text-slate-900">Basic Information</h2>

              <div className="space-y-2">
                <Label htmlFor="productName">
                  Product Name <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="productName"
                  value={productData.name}
                  onChange={(e) => handleFieldChange('name', e.target.value)}
                  placeholder="Enter product name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="productLine">
                  Product Line <span className="text-red-500">*</span>
                </Label>
                <Select
                  value={productData.product_line}
                  onValueChange={(value) => handleFieldChange('product_line', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="NIR Spectroscopy">NIR Spectroscopy</SelectItem>
                    <SelectItem value="Raman Spectroscopy">Raman Spectroscopy</SelectItem>
                    <SelectItem value="Hyperspectral Imaging">Hyperspectral Imaging</SelectItem>
                    <SelectItem value="UV-Vis Spectroscopy">UV-Vis Spectroscopy</SelectItem>
                    <SelectItem value="FTIR Spectroscopy">FTIR Spectroscopy</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={productData.description}
                  onChange={(e) => handleFieldChange('description', e.target.value)}
                  placeholder="Product description..."
                  className="min-h-[120px]"
                />
              </div>
            </CardContent>
          </Card>

          {/* Product Image */}
          <Card className="border-slate-200">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-[18px] font-semibold text-slate-900">Product Image</h2>

              <div className="space-y-4">
                {imagePreview && (
                  <div className="relative w-full aspect-video bg-slate-100 rounded-lg overflow-hidden">
                    <ImageWithFallback
                      src={imagePreview}
                      alt={productData.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                <div className="border-2 border-dashed border-slate-200 rounded-lg p-6">
                  <div className="flex flex-col items-center gap-3">
                    <Upload className="h-12 w-12 text-slate-400" />
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="max-w-xs"
                    />
                    <p className="text-[13px] text-[#6b7280] text-center">
                      Upload new product image (JPG, PNG, WebP)
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pricing */}
          <Card className="border-slate-200">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-[18px] font-semibold text-slate-900">Pricing</h2>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">
                    Price <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    value={productData.price}
                    onChange={(e) => handleFieldChange('price', e.target.value)}
                    placeholder="0.00"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="currency">Currency</Label>
                  <Select
                    value={productData.currency}
                    onValueChange={(value) => handleFieldChange('currency', value)}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="EUR">EUR (€)</SelectItem>
                      <SelectItem value="USD">USD ($)</SelectItem>
                      <SelectItem value="GBP">GBP (£)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Specifications */}
          <Card className="border-slate-200">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-[18px] font-semibold text-slate-900">
                  Technical Specifications
                </h2>
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={addSpecification}
                >
                  <Plus className="h-4 w-4 mr-1" />
                  Add Spec
                </Button>
              </div>

              <div className="space-y-3">
                {specifications.map((spec) => (
                  <div key={spec.id} className="flex gap-3">
                    <Input
                      placeholder="Specification name"
                      value={spec.label}
                      onChange={(e) => updateSpecification(spec.id, 'label', e.target.value)}
                      className="flex-1"
                    />
                    <Input
                      placeholder="Value"
                      value={spec.value}
                      onChange={(e) => updateSpecification(spec.id, 'value', e.target.value)}
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSpecification(spec.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}

                {specifications.length === 0 && (
                  <p className="text-[14px] text-slate-500 text-center py-4">
                    No specifications added yet
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Features */}
          <Card className="border-slate-200">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-[18px] font-semibold text-slate-900">Key Features</h2>

              <div className="space-y-3">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <div className="flex-1 px-3 py-2 bg-slate-50 rounded-md">
                      {feature}
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeFeature(index)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>

              <div className="flex gap-2">
                <Input
                  placeholder="Add a feature..."
                  value={newFeature}
                  onChange={(e) => setNewFeature(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && addFeature()}
                />
                <Button
                  type="button"
                  onClick={addFeature}
                  className="bg-[#00a8b5] hover:bg-[#008a95]"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Publication Status */}
          <Card className="border-slate-200">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-[18px] font-semibold text-slate-900">Publication Status</h2>

              <div className="space-y-3">
                <Label>
                  Status <span className="text-red-500">*</span>
                </Label>
                <RadioGroup
                  value={productData.status}
                  onValueChange={(value: any) => handleFieldChange('status', value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="published" id="published" />
                    <Label htmlFor="published" className="font-normal cursor-pointer">
                      Published (visible to all distributors)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="draft" id="draft" />
                    <Label htmlFor="draft" className="font-normal cursor-pointer">
                      Draft (only visible to admins)
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="archived" id="archived" />
                    <Label htmlFor="archived" className="font-normal cursor-pointer">
                      Archived (hidden from distributors)
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar - Analytics */}
        <div className="lg:col-span-1">
          <Card className="border-slate-200 sticky top-6">
            <CardContent className="p-6 space-y-4">
              <h2 className="text-[18px] font-semibold text-slate-900">Product Analytics</h2>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                    <Eye className="h-5 w-5 text-slate-600" />
                  </div>
                  <div>
                    <p className="text-[24px] font-semibold text-slate-900">{product.views}</p>
                    <p className="text-[13px] text-slate-600">Views</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                    <Download className="h-5 w-5 text-slate-600" />
                  </div>
                  <div>
                    <p className="text-[24px] font-semibold text-slate-900">{product.downloads}</p>
                    <p className="text-[13px] text-slate-600">Downloads</p>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200 space-y-2">
                  <div className="flex justify-between text-[13px]">
                    <span className="text-slate-600">Last updated:</span>
                    <span className="text-slate-900">
                      {new Date(product.updated_at).toLocaleDateString()}
                    </span>
                  </div>
                  <div className="flex justify-between text-[13px]">
                    <span className="text-slate-600">Created:</span>
                    <span className="text-slate-900">
                      {new Date(product.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Fixed Bottom Action Bar */}
      <div className="fixed bottom-0 left-0 right-0 lg:left-64 bg-white border-t border-slate-200 p-4 z-20">
        <div className="max-w-7xl mx-auto flex justify-end gap-3">
          <Button variant="outline" onClick={handleCancel}>
            Cancel
          </Button>
          <Button 
            onClick={handleSave} 
            className="bg-[#00a8b5] hover:bg-[#008a95]"
            disabled={isSaving}
          >
            {isSaving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </div>
      </div>

      {/* Cancel Confirmation Dialog */}
      <AlertDialog open={showCancelDialog} onOpenChange={setShowCancelDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Unsaved Changes</AlertDialogTitle>
            <AlertDialogDescription>
              You have unsaved changes. Are you sure you want to leave? All changes will be lost.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Stay on Page</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmCancel}
              className="bg-red-600 hover:bg-red-700"
            >
              Leave Without Saving
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Product</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{product.name}"? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700"
              disabled={isDeleting}
            >
              {isDeleting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Delete Product
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
