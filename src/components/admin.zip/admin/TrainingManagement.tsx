import React, { useState, useEffect, useTransition } from 'react';
import { Card, CardContent } from '../ui/card';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Badge } from '../ui/badge';
import { Plus, Search, Upload, Edit, Trash2, Video, FileText, Play, MoreVertical } from 'lucide-react';
import { Checkbox } from '../ui/checkbox';
import { Label } from '../ui/label';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from '../ui/dropdown-menu';
import AddTrainingModal from './AddTrainingModal';
import EditTrainingModal from './EditTrainingModal';

const initialTrainings = [
  { 
    id: 1, 
    title: 'NIR Spectroscopy Fundamentals', 
    type: 'Product Training', 
    format: 'Video', 
    level: 'Beginner', 
    duration: '45 min', 
    modules: 6, 
    views: 234, 
    product: 'Visum Palm', 
    status: 'published',
    description: 'Comprehensive introduction to NIR spectroscopy principles and applications',
    internalNotes: 'Popular training module, consider updating with new case studies',
    fileName: 'NIR_Spectroscopy_Fundamentals.mp4',
    fileSize: '125 MB',
    thumbnail: 'nir-thumbnail.jpg',
    lastViewed: '3 hours ago',
    lastViewedBy: 'TechDist Global',
    created: 'Sep 20, 2025',
  },
  { 
    id: 2, 
    title: 'Advanced Raman Techniques', 
    type: 'Product Training', 
    format: 'Video', 
    level: 'Advanced', 
    duration: '60 min', 
    modules: 8, 
    views: 156, 
    product: 'Raman RXN5', 
    status: 'published',
    description: 'Deep dive into advanced Raman spectroscopy methods',
    internalNotes: '',
    fileName: 'Advanced_Raman_Techniques.mp4',
    fileSize: '180 MB',
    thumbnail: 'raman-thumbnail.jpg',
    lastViewed: '1 day ago',
    lastViewedBy: 'EuroPhotonics',
    created: 'Aug 15, 2025',
  },
  { 
    id: 3, 
    title: 'Sales Techniques for Technical Products', 
    type: 'Sales Training', 
    format: 'PDF Guide', 
    level: 'Intermediate', 
    duration: '-', 
    modules: 1, 
    views: 189, 
    product: 'General/All Products', 
    status: 'published',
    description: 'Best practices for selling complex technical equipment',
    internalNotes: 'Updated Q3 2025 with new objection handling section',
    fileName: 'Sales_Techniques_Guide.pdf',
    fileSize: '3.2 MB',
    lastViewed: '5 hours ago',
    lastViewedBy: 'Nordic Tech Solutions',
    created: 'Jul 10, 2025',
  },
  { 
    id: 4, 
    title: 'Hyperspectral Imaging Applications', 
    type: 'Technical Guide', 
    format: 'Video', 
    level: 'Intermediate', 
    duration: '30 min', 
    modules: 4, 
    views: 98, 
    product: 'HyperSpec HS-2000', 
    status: 'published',
    description: 'Real-world applications of hyperspectral imaging',
    internalNotes: 'Consider adding more pharmaceutical examples',
    fileName: 'Hyperspectral_Applications.mp4',
    fileSize: '95 MB',
    thumbnail: 'hyperspec-thumbnail.jpg',
    lastViewed: '2 days ago',
    lastViewedBy: 'Asia Pacific Instruments',
    created: 'Oct 5, 2025',
  },
  { 
    id: 5, 
    title: 'Introduction to Photonics Quality Control', 
    type: 'Product Training', 
    format: 'Video Link', 
    level: 'Beginner', 
    duration: '28 min', 
    modules: 5, 
    views: 312, 
    product: 'General/All Products', 
    status: 'published',
    description: 'Comprehensive overview of photonics-based quality control systems and methodologies',
    internalNotes: 'YouTube video - very popular with new distributors',
    fileName: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    fileSize: 'External',
    thumbnail: 'https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg',
    lastViewed: '1 hour ago',
    lastViewedBy: 'TechDist Global',
    created: 'Oct 15, 2025',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    contentSource: 'videoLink' as 'videoLink',
  },
];

export default function TrainingManagement() {
  const [isPending, startTransition] = useTransition();
  const [trainings, setTrainings] = useState(initialTrainings);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [editingTraining, setEditingTraining] = useState<typeof initialTrainings[0] | null>(null);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Set document title
  useEffect(() => {
    document.title = 'Training Content - IRIS Admin';
    return () => {
      document.title = 'IRIS Admin Portal';
    };
  }, []);

  const handleAddTraining = (newTraining: any) => {
    // Use startTransition for optimistic update
    startTransition(() => {
      setTrainings(prev => [newTraining, ...prev]);
    });
  };

  const handleEditTraining = (training: typeof initialTrainings[0]) => {
    setEditingTraining(training);
    setIsEditModalOpen(true);
  };

  const handleSaveTraining = (updatedTraining: typeof initialTrainings[0]) => {
    // Use startTransition for optimistic update
    startTransition(() => {
      setTrainings(prev => 
        prev.map(training => training.id === updatedTraining.id ? updatedTraining : training)
      );
    });
  };

  const filteredTrainings = trainings.filter((training) =>
    training.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    training.type.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-[28px] font-semibold text-slate-900 mb-2">Training Content</h1>
        <p className="text-[16px] text-[#6b7280]">Manage training videos and guides</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <Button 
          className="bg-[#00a8b5] hover:bg-[#008a95] text-white"
          onClick={() => setIsAddDialogOpen(true)}
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Training Material
        </Button>

        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <Input type="search" placeholder="Search training..." value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} className="pl-10" />
        </div>
      </div>

      <div className="flex gap-6">
        <Card className="w-64 h-fit border-slate-200 hidden lg:block">
          <CardContent className="p-4 space-y-4">
            <div>
              <h3 className="text-[14px] font-semibold text-slate-900 mb-3">Type</h3>
              <div className="space-y-2">
                {['Product Training', 'Sales Training', 'Technical Guide'].map((type) => (
                  <div key={type} className="flex items-center space-x-2">
                    <Checkbox id={type} />
                    <Label htmlFor={type} className="text-[13px] font-normal cursor-pointer">{type}</Label>
                  </div>
                ))}
              </div>
            </div>
            <div className="border-t border-slate-200 pt-4">
              <h3 className="text-[14px] font-semibold text-slate-900 mb-3">Level</h3>
              <div className="space-y-2">
                {['Beginner', 'Intermediate', 'Advanced'].map((level) => (
                  <div key={level} className="flex items-center space-x-2">
                    <Checkbox id={level} />
                    <Label htmlFor={level} className="text-[13px] font-normal cursor-pointer">{level}</Label>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTrainings.map((training) => {
            const Icon = training.format === 'Video' ? Video : FileText;
            return (
              <Card key={training.id} className="border-slate-200 hover:shadow-lg transition-shadow">
                <CardContent className="p-4">
                  <div className="aspect-video bg-slate-100 rounded-lg mb-3 flex items-center justify-center relative">
                    <Icon className="h-12 w-12 text-slate-400" />
                    {training.format === 'Video' && (
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 bg-[#ef4444] rounded-full flex items-center justify-center">
                          <Play className="h-6 w-6 text-white ml-1" />
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2 mb-2">
                    <Badge className="text-[11px]">{training.type}</Badge>
                    <Badge variant="outline" className="text-[11px]">{training.level}</Badge>
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-1 text-[14px]">{training.title}</h3>
                  <p className="text-[12px] text-[#6b7280] mb-2">{training.duration} • {training.modules} modules</p>
                  <p className="text-[12px] text-[#9ca3af] mb-3">Views: {training.views}</p>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" className="flex-1 text-[12px]" onClick={() => handleEditTraining(training)}>
                      <Edit className="mr-1 h-3 w-3" />Edit
                    </Button>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button size="sm" variant="outline"><MoreVertical className="h-3 w-3" /></Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem><Upload className="mr-2 h-4 w-4" />Replace</DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem className="text-red-600"><Trash2 className="mr-2 h-4 w-4" />Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Add Training Modal */}
      <AddTrainingModal
        open={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onAdd={handleAddTraining}
      />

      {/* Edit Training Modal */}
      <EditTrainingModal
        training={editingTraining}
        open={isEditModalOpen}
        onOpenChange={setIsEditModalOpen}
        onSave={handleSaveTraining}
      />
    </div>
  );
}
